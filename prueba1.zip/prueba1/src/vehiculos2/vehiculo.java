package vehiculos2;

public class vehiculo {
	public String obtenerVehiculo() {
		return "aqui se imprime la información del vehiculo";
	}
}
