package vehiculos4;

public interface Vehiculo {
	public String obtenerVehiculo(); 
}
