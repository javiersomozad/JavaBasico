package prueba1;

public class MiApp2 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] numeros;
		
		
		numeros = new int[5];
		
		numeros[0] = 10;
		numeros[1] = 20;
		numeros[2] = 30;
		numeros[3] = 40;
		numeros[4] = 50;
		
		System.out.println(numeros[0]);
		System.out.println(numeros[1]);
		System.out.println(numeros[2]);
		System.out.println(numeros[3]);
		System.out.println(numeros[4]);
	}

}
