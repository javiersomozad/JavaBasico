package prueba1;

public class MiApp {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int entero = 3;
		double decimal = 10.85;
		boolean boleano = true;
		char caracter = 'w';
		
		System.out.println("Hola Mundo");
		System.out.println("este es el valor de la variable entero :" + entero);
		System.out.println("este es el valor de la variable decimal :" + decimal);
		System.out.println("este es el valor de la variable boleano :" + boleano);
		System.out.println("este es el valor de la variable caracter :" + caracter);
	}

}
