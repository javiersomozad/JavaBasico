package vehiculos3;

public class Vehiculo {
	public String obtenerVehiculo() {
		return "aqui se imprime la información del vehiculo";
	}
}
